These are the raw overlap function analysis data from  MD
trajectories supporting the manuscript 'Molecular origins of heterogeneous
aging and spatial organization in RNA condensates' by D Mohanta, H Zhang, D
Thirumalai, and H Nguyen, in Biorxiv
'https://doi.org/10.64898/2026.08.27.747560' and to appear in PNAS.

The equation 5 (overlap function) and equation 7 (pairwise MSD) data for the
whole droplet in subfolder 'whole_droplet_pmsd_overlap' with data
pbw5c31.dat,pbw6c31.dat,..,pbw31c31.dat.
Here wx in the filenames represents the window x. 
lets say pbw5c31.dat represents window 5 which represents observation time
t_w=5*3.296*10^6. similarly pbw6c31.dat represents t_w=6*3.296*10^6.
This overlap function are fit with double exponential (Eq 6) which gives the two time
scales.

The shell wise overlap function and pMSD analysis data in shellwise_droplet_pmsd_overlap folder.
The shellwise MSD (calculated from COM of droplet) data (#col 2) in
shellwise_droplet_msd_overlap folder.
